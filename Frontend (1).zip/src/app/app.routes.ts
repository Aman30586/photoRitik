import { Routes } from '@angular/router';
import { LoginComponent } from './component/login/login.component';
import { UserComponent } from './component/user/user.component';
import { SignUpComponent } from './component/sign-up/sign-up.component';
import { HomeComponent } from './component/home/home.component';
import { AdminComponent } from './component/admin/admin.component';
import { DriverComponent } from './component/driver/driver.component';
import { BookDriveComponent } from './component/user/book-drive/book-drive.component';
import { MyDrivesComponent } from './component/user/my-drives/my-drives.component';
import { AccountComponent } from './component/user/account/account.component';
import { DriverridesComponent } from './component/driver/driverrides/driverrides.component';
import { DriverdetailsComponent } from './component/driver/driverdetails/driverdetails.component';
import { AddDriverComponent } from './component/admin/add-driver/add-driver.component';
import { ViewUsersComponent } from './component/admin/view-users/view-users.component';
import { ViewDriversComponent } from './component/admin/view-drivers/view-drivers.component';
import { ViewDrivesComponent } from './component/admin/view-drives/view-drives.component';

export const routes: Routes = [
    {path: 'login', component:LoginComponent},
    {path: 'signup',component:SignUpComponent},
    {path: 'user', component:UserComponent},
    {path: 'admin', component:AdminComponent},
    {path: 'driver', component:DriverComponent},
    {path: 'book', component:BookDriveComponent},
    {path: 'userrides', component:MyDrivesComponent},
    {path: 'userdetails', component:AccountComponent},
    {path: 'driverrides', component:DriverridesComponent},
    {path: 'driverdetails', component:DriverdetailsComponent},
    {path: 'adddriver', component:AddDriverComponent},
    {path: 'viewusers', component:ViewUsersComponent},
    {path: 'viewdrivers', component:ViewDriversComponent},
    {path: 'viewdrives', component:ViewDrivesComponent},
    {path: '', component:HomeComponent}
];
