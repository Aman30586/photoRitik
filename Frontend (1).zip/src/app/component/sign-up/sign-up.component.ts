import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from './user.service';
import { User } from './user.model';
import { Router, RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-sign-up',
  standalone: true,
  imports: [FormsModule,RouterLink],
  templateUrl: './sign-up.component.html',
  styleUrl: './sign-up.component.css'
})
export class SignUpComponent {

  constructor(private userService: UserService, private router : Router, private toaster: ToastrService){}

    name!: string;
    username!: string;
    email!: string;
    phone!: string;
    password!: string;
    user!:User;

    registerUser(){
      this.user = new User(this.name, this.username, this.email, this.phone, this.password);
      this.userService.resgisterUser(this.user).subscribe((response)=>{
        console.log(response);
        this.toaster.success("Customer registered successfully!", "Success");
        this.router.navigate(['/login']);
      },
      (error)=>{
        let index = 0;
        for(let i = 0; i < error.error.length; i++){
          if(error.error.charAt(i) === ']'){
            index = i;
            break;
          }
        }
        let msg = error.error.substring(38, index);
        this.toaster.error(msg, "Failed");
      })
    }
}
