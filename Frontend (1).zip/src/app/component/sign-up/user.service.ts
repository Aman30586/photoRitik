import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user.model';

@Injectable({
  providedIn: 'root'
})

export class UserService {

  private baseUrl = "http://localhost:9094/auth/registerUser";

  constructor(private http: HttpClient) { }

  resgisterUser(user:User): Observable<any>{
    return this.http.post(`${this.baseUrl}`, user, {responseType : 'text'});
  }
}