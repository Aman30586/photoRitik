import { Car } from "./car.model";

export class Driver{
    name!:string;
    username!:string;
    email!:string;
    phoneNumber!:string;
    licenseNumber!:string;
    address!:string;
    car!:Car;
    constructor(name:string, username:string, email:string, phoneNumber:string, licenseNumber:string, address:string, car:Car){
        this.name = name;
        this.username = username;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.licenseNumber = licenseNumber;
        this.address = address;
        this.car = car;
    }
}