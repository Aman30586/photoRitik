import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Car } from "./car.model";
import { Driver } from "./driver.model";
import { AdminService } from '../admin.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-driver',
  standalone: true,
  imports: [RouterLink, FormsModule],
  templateUrl: './add-driver.component.html',
  styleUrl: './add-driver.component.css'
})
export class AddDriverComponent {

  constructor(private router: Router, private adminService: AdminService, private toaster: ToastrService) { }

  name!:string;
  username!:string;
  email!:string;
  phoneNumber!:string;
  licenseNumber!:string;
  address!:string;
  carName!:string;
  carNumber!:string;
  carType!:string;

  car!:Car;
  driver!:Driver;

  addDriver() {
    this.car = new Car(this.carName, this.carNumber, this.carType);
    this.driver = new Driver(this.name, this.username, this.email, this.phoneNumber, this.licenseNumber, this.address, this.car);
    this.adminService.addDriver(this.driver).subscribe((response) => {
      this.toaster.success(response, "Success");
    },(error)=>{
      let index = 0;
      for(let i = 0; i < error.error.length; i++){
        if(error.error.charAt(i) === ']'){
          index = i;
          break;
        }
      }
      let msg = error.error.substring(38, index);
      this.toaster.error(msg, "Failed");
    })
  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }
}
