export class Car{
    carName!:string;
    carNumber!:string;
    carType!:string;
    constructor(carName:string, carNumber:string, carType:string){
        this.carName = carName;
        this.carNumber = carNumber;
        this.carType = carType;
    }
}