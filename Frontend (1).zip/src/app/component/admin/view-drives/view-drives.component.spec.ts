import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDrivesComponent } from './view-drives.component';

describe('ViewDrivesComponent', () => {
  let component: ViewDrivesComponent;
  let fixture: ComponentFixture<ViewDrivesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewDrivesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ViewDrivesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
