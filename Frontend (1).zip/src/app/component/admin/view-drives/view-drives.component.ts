import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AdminService } from '../admin.service';
import { ToastrService } from 'ngx-toastr';
import { Drives } from './drives.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-view-drives',
  standalone: true,
  imports: [RouterLink, CommonModule],
  templateUrl: './view-drives.component.html',
  styleUrl: './view-drives.component.css'
})
export class ViewDrivesComponent {

  drives!:Drives[];
  changeDate!:Drives[];
  constructor(private router: Router, private adminService: AdminService, private toaster: ToastrService) { }

  ngOnInit(){
    this.adminService.getDrives().subscribe((response) => {
      this.changeDate = response;
      this.convertDateAndTime(this.changeDate);
      // console.log(this.drives);
      this.toaster.info("Drives Details Displayed!", "Information")
    },(error)=>{
      let index = 0;
      for(let i = 0; i < error.error.length; i++){
        if(error.error.charAt(i) === ']'){
          index = i;
          break;
        }
      }
      let msg = error.error.substring(38, index);
      this.toaster.error(msg, "Failed");
    })
  }

  convertDateAndTime(drives:Drives[]){
    for(let i = 0; i < drives.length; i++) {
      const bookDate = new Date(drives[i].bookingDate);
      let endDate = null;
      if(drives[i].endTime != null){
        endDate = new Date(drives[i].endTime);
        drives[i].endDate = endDate.toLocaleDateString();
        drives[i].endTimee = endDate.toLocaleTimeString();
      }
      drives[i].bookDate = bookDate.toLocaleDateString();
      drives[i].bookTime = bookDate.toLocaleTimeString();
    }
    this.drives = drives;
  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }
}
