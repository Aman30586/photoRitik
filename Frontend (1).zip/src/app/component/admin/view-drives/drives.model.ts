export class Drives {
    rideId!:number;
    driverId!:number;
    userId!:number;
    pickUpLocation!:string;
    dropLocation!:string;
    carType!:string;
    bookingDate!:string;
    endTime!:string;
    fare!:number;
    rideStatus!:string;
    bookDate!:string;
    bookTime!:string;
    endDate!:string;
    endTimee!:string;
    constructor(rideId: number, driverId: number, userId: number, pickUpLocation: string, dropLocation: string, carType: string, bookingDate: string, endTime: string, fare: number, rideStatus: string) { 
        this.rideId = rideId;
        this.driverId = driverId;
        this.userId = userId;
        this.pickUpLocation = pickUpLocation;
        this.dropLocation = dropLocation;
        this.carType = carType;
        this.bookingDate = bookingDate;
        this.endTime = endTime;
        this.fare = fare;
        this.rideStatus = rideStatus;
    }
}