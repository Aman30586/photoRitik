import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AdminService } from '../admin.service';
import { ToastrService } from 'ngx-toastr';
import { Driver } from './driver.model';

@Component({
  selector: 'app-view-drivers',
  standalone: true,
  imports: [RouterLink, CommonModule],
  templateUrl: './view-drivers.component.html',
  styleUrl: './view-drivers.component.css'
})
export class ViewDriversComponent {

  drivers!:Driver[];

  constructor(private router: Router, private adminService: AdminService, private toaster: ToastrService) { }

  ngOnInit(){
    this.adminService.getDrivers().subscribe({next:(response) => {
      this.drivers = response;
      this.toaster.info("Driver Details Displayed!", "Information")
    },error:(error)=>{
      let index = 0;
      for(let i = 0; i < error.error.length; i++){
        if(error.error.charAt(i) === ']'){
          index = i;
          break;
        }
      }
      let msg = error.error.substring(38, index);
      this.toaster.error(msg, "Failed");
  }})
  }

  deleteDriver(driverId:number){
    if(window.confirm("Are you sure you want to delete Driver with ID : " + driverId)){
      this.adminService.deleteDriver(driverId).subscribe((response) => {
        console.log(response);
        this.toaster.success("Driver Deleted!", "Success");
      })
      this.reload();
    }
  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }

  reload(){
    window.location.reload();
  }
}
