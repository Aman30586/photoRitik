import { Car } from "./car.model";

export class Driver{
    driverId!:number;
    name!:string;
    username!:string;
    email!:string;
    phoneNumber!:string;
    licenseNumber!:string;
    address!:string;
    car!:Car;
    constructor(driverId:number, name:string, username:string, email:string, phoneNumber:string, licenseNumber:string, address:string, car:Car){
        this.driverId = driverId;
        this.name = name;
        this.username = username;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.licenseNumber = licenseNumber;
        this.address = address;
        this.car = car;
    }
}