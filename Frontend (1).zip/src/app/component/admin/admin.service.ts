import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Driver } from './add-driver/driver.model';
import { User } from './view-users/user.model';
import { Drives } from './view-drives/drives.model';

@Injectable({
  providedIn: 'root'
})

export class AdminService {

  private baseUrlDriver = "http://localhost:9094/driver/";
  private baseUrlUser = "http://localhost:9094/user/";
  private baseUrlDrive = "http://localhost:9094/ride/";

  constructor(private http: HttpClient) { }

  addDriver(driver:Driver): Observable<any>{

    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.post(this.baseUrlDriver+"register", driver, {responseType: "text", headers});
  }

  getDrivers():Observable<any[]>{
    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.get<Driver[]>(this.baseUrlDriver+"display", {headers});
  }

  getUsers(): Observable<User[]>{
    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });

    return this.http.get<User[]>(this.baseUrlUser+"display", {headers});
  }

  getDrives():Observable<Drives[]> {
    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });

    return this.http.get<Drives[]>(this.baseUrlDrive+"display", {headers});
  }

  deleteDriver(driverId:number):Observable<any>{
    let token = sessionStorage.getItem('token');
    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.delete(this.baseUrlDriver+"deleteDriver/"+driverId, {responseType:'text', headers});
  }
}