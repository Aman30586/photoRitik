import { Component } from '@angular/core';
import { CredentialsService } from './credentials.service'
import { FormsModule } from '@angular/forms';
import { Credentials } from './credentials.model';
import { error } from 'node:console';
import { Router, RouterLink } from '@angular/router';
import { jwtDecode } from 'jwt-decode';
import { Response } from './response.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule,RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  ngOnInit(){
    //sessionStorage.clear();
  }

  username!:string;
  password!:string;
  credentials!:Credentials;
  user!:Response;

  constructor(private credentialsService: CredentialsService, private router: Router, private toaster: ToastrService){}

  sendCredentials(){
    this.credentials = new Credentials(this.username, this.password);
    this.credentialsService.getToken(this.credentials).subscribe((response) => {
      this.toaster.success("Login successfull!!", "Success");
      this.user = response
      console.log(this.user);
      sessionStorage.setItem("username", response.name);
      sessionStorage.setItem("id", response.id);
      sessionStorage.setItem("token", response.token);
      if(this.user.role == "USER"){
        this.router.navigate(['/user']);
      }
      else if(this.user.role == "ADMIN"){
        this.router.navigate(['/admin']);
      }
      else if(this.user.role == "DRIVER"){
        this.router.navigate(['/driver']);
      }
    },
    (error) => {
      console.log(error);
      this.toaster.error("Invalid Credentials!", "Failed")
    })
  }

}
