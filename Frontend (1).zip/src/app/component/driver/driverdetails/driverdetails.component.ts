import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { DriverService } from '../driver.service';
import { ToastrService } from 'ngx-toastr';
import { Driver } from './driver.model';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-driverdetails',
  standalone: true,
  imports: [RouterLink, FormsModule],
  templateUrl: './driverdetails.component.html',
  styleUrl: './driverdetails.component.css'
})
export class DriverdetailsComponent {

  constructor(private router: Router, private service: DriverService, private toaster: ToastrService){}
  driver!:Driver;
  createdAt!:string;
  updatedAt!:string;

  attribute:string = "Name";
  value!:string;

  updateDetail(){
    this.value.replaceAll(" ", "_")
    this.service.updateDetails(this.attribute, this.value).subscribe((response) => {
      this.reload();
      this.toaster.info("Updated details!", "Information");
    });
  }

  ngOnInit(){
    this.service.getDriverDetails().subscribe((response) => {
      this.driver = response;
    })
  }

  reload(){
    window.location.reload();
  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }

}
