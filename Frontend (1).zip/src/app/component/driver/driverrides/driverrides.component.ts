import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { DriverResponse } from '../driverResponse.model';
import { DriverService } from '../driver.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-driverrides',
  standalone: true,
  imports: [RouterLink, CommonModule],
  templateUrl: './driverrides.component.html',
  styleUrl: './driverrides.component.css'
})
export class DriverridesComponent {

  constructor(private router: Router, private driverService: DriverService, private toaster: ToastrService){}

  driverResponse!: DriverResponse[];
  bookedDrive!: DriverResponse;
  completedDrives!:DriverResponse[];

  flag:boolean = false;

  ngOnInit(){
    this.driverService.getRides().subscribe((response) => {
      this.driverResponse = response;
      for(let drive of this.driverResponse){
        if(drive.rideStatus === "Booked"){
          let index = this.driverResponse.indexOf(drive);
          this.bookedDrive = drive;
          this.flag = true;
          this.driverResponse.splice(index, 1);
          break;
        }
      }
      this.completedDrives = this.driverResponse;
    },(error) =>{
      console.log(error);
      this.toaster.error(error.error.message, "Failed");
    })
  }

  endRide(rideId: number){
    this.driverService.endRide(rideId).subscribe((response) => {
      console.log(response);
      this.toaster.info("Drive Completed!", "Information");
      this.reload();
    })
  }

  logout(){
    sessionStorage.clear();
    this.router.navigate(['/']);
  }

  reload(){
    window.location.reload();
  }

}
