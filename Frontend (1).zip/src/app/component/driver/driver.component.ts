import { UpperCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-driver',
  standalone: true,
  imports: [RouterLink, UpperCasePipe],
  templateUrl: './driver.component.html',
  styleUrl: './driver.component.css'
})
export class DriverComponent {

  username = sessionStorage.getItem("username");

  constructor(private router: Router){}

  logout(){
    sessionStorage.clear();
    this.router.navigate(['']);
  }
}
