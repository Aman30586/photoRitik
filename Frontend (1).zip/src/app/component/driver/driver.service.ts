import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Driver } from './driverdetails/driver.model';

@Injectable({
  providedIn: 'root'
})

export class DriverService {

  private baseUrl = "http://localhost:9094/ride/";
  constructor(private http: HttpClient) { }

  getRides(): Observable<any>{
    let id = sessionStorage.getItem("id");
    let token = sessionStorage.getItem("token");
    const headers = new HttpHeaders({
        'Authorization' : `Bearer ${token}`
    })
    return this.http.get(this.baseUrl+"displayRidesByDriverId/"+id, {headers});
  }

  endRide(rideId:number): Observable<any>{
    let id = sessionStorage.getItem("id");
    let token = sessionStorage.getItem("token");
    const headers = new HttpHeaders({
        'Authorization' : `Bearer ${token}`
    })
    return this.http.get(this.baseUrl+"endRide/"+rideId, {responseType:'text' ,headers});
  }

  getDriverDetails():Observable<Driver>{
    let driverId = sessionStorage.getItem('id');

    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.get<Driver>("http://localhost:9094/driver/display/"+driverId, {headers});
  }

  updateDetails(attribute:string, value:string){
    let driverId = sessionStorage.getItem('id');

    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.put("http://localhost:9094/driver/updateDetails/"+driverId+"/"+attribute+"/"+value, null,{headers});
  }
}