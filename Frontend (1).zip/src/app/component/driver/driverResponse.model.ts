import { User } from "./user.model";

export class DriverResponse{
    rideId!: number;
    pickUpLocation!: string;
    dropLocation!: string;
    user!: User;
    rideStatus!: string;
    fare!: number;
    constructor(rideId:number, pickUpLocation:string, dropLocation:string, user:User, rideStatus:string, fare:number){
        this.rideId = rideId;
        this.pickUpLocation = pickUpLocation;
        this.dropLocation = dropLocation;
        this.user = user;
        this.rideStatus = rideStatus;
        this.fare = fare;
    }
}