import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { RideService } from '../book-drive/ride.service';
import { User } from './user.model';
import { FormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-account',
  standalone: true,
  imports: [RouterLink, FormsModule],
  templateUrl: './account.component.html',
  styleUrl: './account.component.css'
})
export class AccountComponent {

  constructor(private router: Router, private service: RideService, private toaster: ToastrService){}

  user!:User;
  createdAt!:string;
  updatedAt!:string;

  attribute:string = "Name";
  value!:string;

  deleteUser(userId:number){
    if(window.confirm("Are you sure, you want to delete this account?")){
      this.service.deleteUser(userId).subscribe((response) => {
        this.toaster.success("Account Deleted Successfully!", "Success");
        this.router.navigate(['/']);
      });
    }
  }

  updateDetail(){
    this.value.replaceAll(" ", "_")
    this.service.updateDetails(this.attribute, this.value).subscribe((response) => {
      this.reload();
      this.toaster.info("Updated details!", "Information");
    });
  }

  ngOnInit(){
    this.service.getUserDetails().subscribe((response) => {
      this.user = response;
      this.convertDateAndTime(this.user)
    })
  }

  convertDateAndTime(user:User){
      const created = new Date(user.createdAt);
      this.createdAt = created.toLocaleDateString();
      const updated = new Date(user.updatedAt);
      this.updatedAt = updated.toLocaleDateString();
  }

  logout(){
    console.log("Clicked...");
    sessionStorage.clear();
    this.router.navigate(['/']);
  }

  reload(){
    window.location.reload();
  }
}
