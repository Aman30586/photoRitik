import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { RideService } from '../book-drive/ride.service';
import { error } from 'console';
import { RideResponse } from '../book-drive/rideResponse.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-my-drives',
  standalone: true,
  imports: [RouterLink, CommonModule],
  templateUrl: './my-drives.component.html',
  styleUrl: './my-drives.component.css'
})
export class MyDrivesComponent {

  constructor(private rideService: RideService, private router: Router){}

  rideResponse!:any;
  bookedDrive!: RideResponse;
  completedDrives!:RideResponse[];

  flag:boolean = false;

  ngOnInit() {
    this.rideService.getMyDrives().subscribe((response) => {
      this.rideResponse = response;
      for(let drive of this.rideResponse){
        if(drive.rideStatus === "Booked"){
          let index = this.rideResponse.indexOf(drive);
          this.bookedDrive = drive;
          this.flag = true;
          this.rideResponse.splice(index, 1);
          break;
        }
      }
      this.completedDrives = this.rideResponse;
    },
    (error) => {
      console.log(error);
    })
  }

  logout(){
    console.log("Clicked...");
    sessionStorage.clear();
    this.router.navigate(['']);
  }
}
