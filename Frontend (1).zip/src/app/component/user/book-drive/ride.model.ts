export class Ride{
    pickUpLocation!:string;
    dropLocation!:string;
    carType!:string;
    constructor(pickUpLocation:string, dropLocation:string, carType:string){
        this.pickUpLocation = pickUpLocation;
        this.dropLocation = dropLocation;
        this.carType = carType;
    }
}