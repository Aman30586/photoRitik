import { Car } from "./car.model";

export class Driver{
    driverId!:number;
    name!:string;
    phoneNumber!:number;
    car!:Car;
}