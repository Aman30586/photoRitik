import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ride } from './ride.model';
import { User } from '../account/user.model';

@Injectable({
  providedIn: 'root'
})

export class RideService {

  private baseUrl = "http://localhost:9094/ride/";
  
  constructor(private http: HttpClient) { }
  
  bookRide(ride:Ride): Observable<any>{
    let userId = sessionStorage.getItem('id');

    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.post(this.baseUrl+"bookride/"+userId, ride, {headers});
  }

  cancelRide(rideId:number){

    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.get(this.baseUrl+"cancelRide/"+rideId, {responseType:'text', headers});
  }

  getMyDrives(){
    let userId = sessionStorage.getItem('id');

    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.get(this.baseUrl+"displayRidesByUserId/"+userId, {headers});
  }

  getUserDetails():Observable<User>{
    let userId = sessionStorage.getItem('id');

    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.get<User>("http://localhost:9094/user/display/"+userId, {headers});
  }

  updateDetails(attribute:string, value:string){
    let userId = sessionStorage.getItem('id');

    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.put<User>("http://localhost:9094/user/updateDetails/"+userId+"/"+attribute+"/"+value, null,{headers});
  }

  getEstimatedFare(pickup:string, drop:string, carType:string):Observable<any>{
    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.get(this.baseUrl+"getFare/"+pickup+"/"+drop+"/"+carType, {responseType:'text', headers});
  }

  deleteUser(userId:number):Observable<any>{
    let token = sessionStorage.getItem('token');

    const headers = new HttpHeaders({
          'Authorization': `Bearer ${token}`
    });

    return this.http.delete("http://localhost:9094/user/deleteUser/"+userId, {responseType:'text', headers});
  }
}