export class Car{
    carNumber!:string;
	carType!:string;
	carName!:string;
}