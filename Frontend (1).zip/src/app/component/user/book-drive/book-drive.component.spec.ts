import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookDriveComponent } from './book-drive.component';

describe('BookDriveComponent', () => {
  let component: BookDriveComponent;
  let fixture: ComponentFixture<BookDriveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BookDriveComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BookDriveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
