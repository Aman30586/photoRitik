import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { Ride } from './ride.model';
import { RideService } from './ride.service';
import { RideResponse } from './rideResponse.model';
import { CommonModule } from '@angular/common';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-book-drive',
  standalone: true,
  imports: [RouterLink, FormsModule, CommonModule],
  templateUrl: './book-drive.component.html',
  styleUrl: './book-drive.component.css'
})
export class BookDriveComponent {

  constructor(private rideService: RideService, private router: Router, private toaster: ToastrService) { }

  pickUpList:string[] = ["Ecospace", "Bellandur", "Green Glen Layout", "Sarajapur Rd", "HSR Layout", "Kundlahalli", "Kormangla", "MG Road", "Indira Nagar", "KIA"];
  dropList:string[] = ["Ecospace", "Bellandur", "Green Glen Layout", "Sarajapur Rd", "HSR Layout", "Kundlahalli", "Kormangla", "MG Road", "Indira Nagar", "KIA"];
  temp!:string;
  count:number = 0;

  pickupLocation: string = "Pickup Location";
  dropLocation: string = "Drop Location";
  carType: string = "Micro";
  estimatedFare!:string;
  flag: boolean = false;
  estiFlag:boolean = false;
  ride!: Ride;
  rideResponse!: RideResponse;

  updateList(){
    let index = this.dropList.indexOf(this.pickupLocation);
    if(index >= 0){
      if(this.count > 0){
        this.dropList.push(this.temp);
      }
      this.dropList.splice(index,1);
      this.temp = this.pickupLocation;
      this.count++;
    }
  }

  getEstimatedFare(){
    this.pickupLocation.replaceAll(" ", "_");
    this.dropLocation.replaceAll(" ", "_");
    this.rideService.getEstimatedFare(this.pickupLocation, this.dropLocation, this.carType).subscribe((response) => {
      this.estimatedFare = response;
      console.log(response);
      console.log(this.estimatedFare);
      this.estiFlag = true;
    });
  }

  bookRide() {
    this.ride = new Ride(this.pickupLocation, this.dropLocation, this.carType);
    this.rideService.bookRide(this.ride).subscribe((response) => {
      this.rideResponse = response;
      this.flag = true;
      this.estiFlag = false;
      this.toaster.success("Ride booked successfully!", "Success");
      console.log(this.rideResponse);
    }, (error) => {
      this.toaster.error(error.error[0].message, "Failed");
    });
  }

  cancelRide(rideId: number) {
    this.rideService.cancelRide(rideId).subscribe((response) => {
      console.log(response);
      alert("Are you sure you want to cancel this ride?");
      this.reload();
      this.toaster.success("Drive Cancelled!", "Success");;
    },(error) => {
      console.log
      let index = 0;
        for(let i = 0; i < error.error.length; i++){
          if(error.error.charAt(i) === ']'){
            index = i;
            break;
          }
        }
        let msg = error.error.substring(38, index);
        console.log(msg);
        this.toaster.error(msg, "Failed");
        this.router.navigate(['/userrides'])
    })
  }

  logout() {
    sessionStorage.clear();
    this.router.navigate(['']);
  }

  reload(){
    window.location.reload();
  }

}
