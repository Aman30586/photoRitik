import { Driver } from "./driver.model";

export class RideResponse {
    rideId!:number;
    pickUpLocation!: String;
    dropLocation!: String;
    driver!: Driver;
    rideStatus!: String;
    fare!: number;
}