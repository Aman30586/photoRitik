import { UpperCasePipe } from '@angular/common';
import { Component, Pipe } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [UpperCasePipe, RouterLink],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {

  username = sessionStorage.getItem("username");

  constructor(private router: Router){}

  logout(){
    console.log("Clicked...");
    sessionStorage.clear();
    this.router.navigate(['']);
  }
}
